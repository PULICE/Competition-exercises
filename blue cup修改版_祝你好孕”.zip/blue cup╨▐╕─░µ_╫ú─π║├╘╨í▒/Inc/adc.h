#ifndef _ADC_H_
#define _ADC_H_

void Adc_GPIOInit(void);
unsigned int ADC1_Conv(void);
#endif
