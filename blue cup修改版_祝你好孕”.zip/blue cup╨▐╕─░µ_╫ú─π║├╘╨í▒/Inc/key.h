#ifndef _KEY_H_
#define _KEY_H_

#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x.h"
void Key_Init(void);
#endif
